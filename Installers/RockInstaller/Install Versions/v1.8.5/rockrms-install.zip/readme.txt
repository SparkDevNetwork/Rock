                         `oyy/                 
                       `+NMMMMd:               
                      :mMMMMMMMMy-             
                    -hMMMMNydMMMMNs.           
                  .sNMMMMh-  /mMMMMm+`         
                `oNMMMMm/     `oNMMMMd:        
               -hmmmmmo`   `....:dMMMMMh-      
               ```````    ommmmmmNMMMMMMNs     
                          dMMMMMMMMMMMMMMm     
                          `oNMMMMMh+++++/.     
                            .yMMMMMh-          
                              :dMMMMNs`        
                               `/mMMMMm+`      
                                 `ohhhhyo` 

==================================================================
                            W E L C O M E
==================================================================

This zip file includes the Start.aspx file needed to begin the
Rock RMS install.  Simply place it on your webserver and navigate
to it from your web browser (e.x. http://yourserver.com/Start.aspx)

==================================================================