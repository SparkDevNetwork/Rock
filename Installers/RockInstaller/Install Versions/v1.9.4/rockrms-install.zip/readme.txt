This zip file includes the Start.aspx and web.config files needed to begin
the Rock RMS install. Simply place them on your webserver and navigate
to Start.aspx from your web browser (e.x. http://yourserver.com/Start.aspx).